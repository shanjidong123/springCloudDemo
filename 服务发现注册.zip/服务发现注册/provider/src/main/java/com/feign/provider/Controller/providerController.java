package com.feign.provider.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.feign.provider.Service.providerService;

@Controller
public class providerController {
    @Autowired
    private providerService providerService;

    @RequestMapping(value = "/hello",method = RequestMethod.GET)
    @ResponseBody
    public String say(String name){
        return providerService.say(name);
    }
}
