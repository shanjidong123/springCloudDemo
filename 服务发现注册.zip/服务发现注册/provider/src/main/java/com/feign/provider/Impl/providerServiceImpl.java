package com.feign.provider.Impl;

import org.springframework.stereotype.Service;
import com.feign.provider.Service.providerService;

@Service
public class providerServiceImpl implements providerService{
    @Override
    public String say(String name) {
        return "hello:"+name;
    }
}
