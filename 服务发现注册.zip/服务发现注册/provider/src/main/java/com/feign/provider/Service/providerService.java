package com.feign.provider.Service;

public interface providerService {
    String say(String name);
}
