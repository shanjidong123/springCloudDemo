package com.cloud.eurka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurkaApplicationTests {

    @Test
    void contextLoads() {
    }

}
