package com.feignthree.consumertwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumertwoApplicationTests {

    @Test
    void contextLoads() {
    }

}
