package com.feignthree.consumertwo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class helloService {
    @Autowired
    private RestTemplate restTemplate;

    public String say(String name){
        return restTemplate.getForObject("http://produce/hello?name="+name,String.class);
    }
}
