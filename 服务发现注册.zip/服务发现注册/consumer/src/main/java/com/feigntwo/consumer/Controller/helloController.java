package com.feigntwo.consumer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import com.feigntwo.consumer.Service.helloService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class helloController {
    @Autowired
    private helloService helloService;

    @RequestMapping(value = "/say",method = RequestMethod.GET)
    @ResponseBody
    public String say(String name){
        return helloService.sayHello(name);
    }

}
